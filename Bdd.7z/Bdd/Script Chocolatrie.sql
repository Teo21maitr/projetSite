
set sql_safe_updates=0;

CREATE TABLE client(
   idClient INT,
   nomClient VARCHAR(50),
   adresseClient VARCHAR(50),
   telephoneClient INT,
   PRIMARY KEY(idClient)
);
alter table client add column age int;
alter table client add column codePostalClient int(5);
alter table client add column nationnalité varchar(45);
alter table client add column sexe varchar(1);

#Création d'indexes table client
create index nomClient_index on client(nomClient);


CREATE TABLE ligne(
   idLigne INT,
   nomLigne VARCHAR(50),
   PRIMARY KEY(idLigne)
);

CREATE TABLE Entrepots(
   idEntrepot INT,
   adresseEntrepot VARCHAR(50),
   capacitéDeStockage INT NOT NULL,
   PRIMARY KEY(idEntrepot)
);

CREATE TABLE packaging(
   idPackaging INT,
   nomPackaging VARCHAR(50),
   PRIMARY KEY(idPackaging)
);

CREATE TABLE catégorie(
   idCatégorie INT,
   nomCatégorie VARCHAR(50),
   PRIMARY KEY(idCatégorie)
);

create index nomCatégorie_index on catégorie(nomCatégorie);

CREATE TABLE fournisseur(
   idFabriquant INT,
   nomFournisseur VARCHAR(50),
   adresseFournisseur VARCHAR(64),
   telephoneFournisseur VARCHAR(50),
   PRIMARY KEY(idFabriquant)
);
alter table fournisseur add column codePostalFournisseur INT(5);
alter table fournisseur add column nationnalité varchar(45);


CREATE TABLE consommable(
   idConsommable INT,
   nomConsomable VARCHAR(50),
   poids DECIMAL(5,2),
   capacitéDeProduction INT,
   tempsConfection INT,
   tailleEnmm VARCHAR(50),
   idCatégorie INT NOT NULL,
   idLigne INT NOT NULL,
   PRIMARY KEY(idConsommable),
   FOREIGN KEY(idCatégorie) REFERENCES catégorie(idCatégorie),
   FOREIGN KEY(idLigne) REFERENCES ligne(idLigne)
);

create index nomConsomable_index on consommable(nomConsomable);
create index Poids_index on consommable(poids);


CREATE TABLE ingrédient(
   idIngredient INT,
   nomIngrédient VARCHAR(50),
   prixIngrédientAuKg decimal(4,2),
   DélaiLivraison TIME,
   idFabriquant INT NOT NULL,
   PRIMARY KEY(idIngredient),
   FOREIGN KEY(idFabriquant) REFERENCES fournisseur(idFabriquant)
);


CREATE TABLE produit(
   idProduit INT,
   prix VARCHAR(50) NOT NULL,
   dateProduction DATETIME,
   poids INT,
   idConsommable INT NOT NULL,
   idPackaging INT NOT NULL,
   PRIMARY KEY(idProduit),
   FOREIGN KEY(idConsommable) REFERENCES consommable(idConsommable),
   FOREIGN KEY(idPackaging) REFERENCES packaging(idPackaging)
);

create index PrixProduit_index on produit(prix);


CREATE TABLE commander(
   idClient INT,
   idProduit INT,
   dateCommande DATE,
   quantitéCommandée INT NOT NULL,
   PRIMARY KEY(idClient, idProduit),
   FOREIGN KEY(idClient) REFERENCES client(idClient),
   FOREIGN KEY(idProduit) REFERENCES produit(idProduit)
);

alter table commander add  column satisfaction_client int;   #correspond à une une note sur 10
alter table commander add  column delai_livraison time;

CREATE INDEX quantité_commande_index ON commander(quantitéCommandée);

CREATE TABLE Stocker(
   idEntrepot INT,
   idProduit INT,
   DateEntrée DATETIME,
   DateSortie DATETIME,
   PRIMARY KEY(idEntrepot, idProduit),
   FOREIGN KEY(idEntrepot) REFERENCES Entrepots(idEntrepot),
   FOREIGN KEY(idProduit) REFERENCES produit(idProduit)
);

CREATE TABLE fabriquer(
   idConsommable INT,
   idIngredient INT,
   idRecette INT,
   nomRecette VARCHAR(50),
   PRIMARY KEY(idConsommable, idIngredient),
   FOREIGN KEY(idConsommable) REFERENCES consommable(idConsommable),
   FOREIGN KEY(idIngredient) REFERENCES ingrédient(idIngredient)
);
#--------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------
#                                     REQUETES
#--------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------


#---------------------------------------REQUETE AFFICHAGE LISTE CLIENT ET FOURNISSEUR-------------------------------------------------------------------
#trier les clients par ordre alphabétique
CREATE VIEW Clients_liste AS
SELECT   
    *
FROM
    client
ORDER BY nomClient;    
#  ------------------
#trier les fournisseurs par ordre alphabétique
CREATE VIEW Fournisseurs_listes AS
SELECT 				   
    *
FROM
    fournisseur
ORDER BY nomFournisseur;

#   ---------------

#Rechercher les clients qui viennent de dijon
CREATE VIEW Clients_de_Dijon AS
SELECT 
    nomClient, telephoneClient
FROM
    client
WHERE
    LOWER(adresseClient) LIKE '%dijon%';
#      -------------------------
#Afficher les fournisseurs qui viennent de dijon
CREATE VIEW Fournisseur_de_Dijon AS
SELECT 
    nomFournisseur, telephoneFournisseur
FROM
    fournisseur
WHERE
    LOWER(adresseFournisseur) LIKE '%dijon%';
#      ---------------------------
#Afficher les clients qui viennent de côte d'or
CREATE VIEW Clients_de_Côte_D_or AS
SELECT 
    nomClient, telephoneClient
FROM
    client
WHERE
    codePostalClient LIKE '21%';
#      --------------------
#Afficher les fournisseurs qui viennent de cote d'or
CREATE VIEW Fournisseur_de_Côte_dor AS
SELECT 
    nomFournisseur, telephoneFournisseur
FROM
    fournisseur
WHERE
    codePostalFournisseur LIKE '21%';
#--------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------


#---------------------------------REQUETE AFFICHAGE PRODUITS ET CARACTERISTIQUES--------------------------------------------------------------------------	

#Afficher les consommables et la catégorie auxquels ils appartiennent par ordre alphabétique des catégorie puis des consommables
CREATE VIEW Consommable_et_Catégorie AS
SELECT 
    catégorie.nomCatégorie, consommable.nomConsomable
FROM
    consommable
        NATURAL JOIN
    catégorie
ORDER BY catégorie.nomCatégorie , consommable.nomConsomable;
#         ----------------------
#afficher ce que produisent les lignes comme produit
CREATE VIEW Consommables_et_ligne AS
SELECT 
    ligne.nomLigne, consommable.nomConsomable
FROM
    consommable
        NATURAL JOIN
    ligne
ORDER BY nomLigne , nomConsomable;
#        ------------------------
#afficher les produit fabriqués avec des ingrédients du département
CREATE VIEW Produits_locaux AS
SELECT DISTINCT
    consommable.nomConsomable AS produits_locaux
FROM
    fournisseur
        INNER JOIN
    ingrédient ON fournisseur.idFabriquant = ingrédient.idIngredient
        NATURAL JOIN
    consommable
WHERE
    fournisseur.codePostalFournisseur LIKE '21%';
#           ----------------------
#Afficher où les produits peuvent être stocké
CREATE VIEW Lieu_stockage_produit AS
SELECT DISTINCT
    (consommable.nomConsomable), entrepots.adresseEntrepot
FROM
    consommable
        INNER JOIN
    produit ON consommable.idConsommable = produit.idConsommable
        INNER JOIN
    stocker ON produit.idConsommable = stocker.idProduit
        INNER JOIN
    entrepots ON stocker.idEntrepot = entrepots.idEntrepot; 
 #             -------------------------   
#afficher les consommables avec leur emballages
CREATE VIEW Consommable_et_packaging_donc_produit AS
SELECT DISTINCT
    (consommable.nomConsomable), packaging.nomPackaging
FROM
    consommable
        INNER JOIN
    produit ON consommable.idConsommable = produit.idConsommable
        INNER JOIN
    packaging ON produit.idPackaging = packaging.idPackaging
ORDER BY consommable.nomConsomable;
#                -------------------------
#afficher les consommables qui possèdent plusieurs emballge différents
CREATE VIEW Consommables_avec_différents_emballages AS
SELECT 
    COUNT(packaging.idPackaging) AS nb_emballage,
    consommable.nomConsomable
FROM
    consommable
        INNER JOIN
    produit ON consommable.idConsommable = produit.idConsommable
        INNER JOIN
    packaging ON produit.idPackaging = packaging.idPackaging
GROUP BY consommable.idConsommable
HAVING nb_emballage > 1
ORDER BY consommable.nomConsomable;

#----------------------------------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------------------------------------


#-----------------------------REQUETE SUR LE BILAN DE L'ENTRPRISE ET AIDE PRISE DE DECISION-------------------------------------------------------------------------------------------


#Afficher le poids total vendu des consommables par odre alphabétique
CREATE VIEW Bilan_produit_poids_vendu AS
SELECT 
    produit.poids * commander.quantitéCommandée AS poids_vendu,
    consommable.nomConsomable
FROM
    consommable
        INNER JOIN
    produit ON consommable.idConsommable = produit.idConsommable
        JOIN
    commander
GROUP BY consommable.idConsommable
ORDER BY consommable.nomConsomable;

#        --------------------

#Afficher le chiffre d'affaire par mois en additionnant pour 2020 et 2021
CREATE VIEW Chiffre_affaire_par_mois AS
SELECT 
    SUM(produit.prix * commander.quantitéCommandée) AS Chiffre_par_mois,
    MONTH(commander.dateCommande) AS mois
FROM
    produit
        NATURAL JOIN
    commander
GROUP BY mois;

#        --------------------

#Afficher le mois le plus lucratif pour l'entreprise
CREATE VIEW Mois_le_plus_lucratif AS
SELECT 
    SUM(produit.prix * commander.quantitéCommandée) AS Chiffre_par_mois,
    MONTH(commander.dateCommande) AS mois
FROM
    produit
        NATURAL JOIN
    commander
GROUP BY mois
ORDER BY Chiffre_par_mois DESC
LIMIT 1;

#        --------------------

#Afficher le chiffre d'affaire par année
CREATE VIEW Chiffre_affaire_par_an AS
SELECT 
    SUM(produit.prix * commander.quantitéCommandée) AS Chiffre_par_an,
    YEAR(commander.dateCommande) AS année
FROM
    produit
        NATURAL JOIN
    commander
GROUP BY année
ORDER BY année;

#        --------------------

#afficher quels consommables rapportent le plus d'argent
CREATE VIEW Produits_les_plus_vendus AS
SELECT 
    consommable.nomConsomable,
    produit.prix * commander.quantitéCommandée AS prix_total
FROM
    consommable
        INNER JOIN
    produit ON consommable.idConsommable = produit.idConsommable
        NATURAL JOIN
    commander
GROUP BY produit.idProduit
ORDER BY prix_total DESC
limit 5;

#     --------------

/*afficher les produit qui ont pas été commandés, ne retourne rien car tous les produits 
de la base de données sont commandés au moins une fois mais fonctionne*/
CREATE VIEW Produit_non_commandé AS
SELECT 
    consommable.nomConsomable
FROM
    consommable
        INNER JOIN
    produit ON consommable.idConsommable = produit.idProduit
        INNER JOIN
    commander ON produit.idProduit = commander.idProduit
WHERE
    produit.idProduit NOT IN (SELECT 
            commander.idProduit
        FROM
            commander);

#------------------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------------------------------------


#-------------------------REQUETE RECUPERANT DES DONNEES SUR LES CLIENTS ET AIDANT A LA PRISE DE DECISION-----------------------------------------------------------------------------------

# Afficher les clients par orde alphabétiques avec leur nombre de commande
CREATE VIEW Clients_nb_commande AS
SELECT 
    nomClient, COUNT(idClient) AS Nb_commande
FROM
    client
        NATURAL JOIN
    commander
GROUP BY client.idClient
ORDER BY nomClient;

#      ----------------

#Affiche les 3 clients les plus fidèles
CREATE VIEW Clients_les_plus_fidèles AS
SELECT 
    nomClient, COUNT(idClient) AS Nb_commande
FROM
    client
        NATURAL JOIN
    commander
GROUP BY client.idClient
ORDER BY Nb_commande DESC
LIMIT 3;

#          ----------------

#Afficher les clients qui ont fait les commandes les plus chères par ordre décroissant
CREATE VIEW Classement_du_plus_gros_client_au_moins_gros AS
SELECT 
    produit.prix * commander.quantitéCommandée AS prix_commande,
    client.nomClient
FROM
    produit
        NATURAL JOIN
    commander
        NATURAL JOIN
    client
GROUP BY client.idClient
ORDER BY prix_commande DESC;

#      ----------------

#moyenne d'age des clients
CREATE VIEW Clients_moyenne_age AS
SELECT 
    AVG(client.age) AS moyenne_age_client
FROM
    client;
 
 #    ---------------
 
/*afficher depuis combien de jours un client à fait sa dernière commande avec 
une marge d'erreur de 2 jours car on fixe dans le calcul la taille d'un mois à 30 jours*/
CREATE VIEW Clients_nb_jour_depuis_dernière_commande AS
SELECT 
    client.nomClient AS Nom_des_clients,
    client.telephoneClient,
    MAX(commander.dateCommande) AS dernière_commande,
    ((360 * (YEAR(NOW()) - YEAR(commander.dateCommande))) + (30 * (MONTH(NOW()) - MONTH(commander.dateCommande))) + (DAY(NOW()) - DAY(commander.dateCommande))) 
    AS temps_écoulé_depuis_dernière_commande_en_jour
FROM
    client
        INNER JOIN
    commander ON client.idClient = commander.idClient
GROUP BY client.idClient
ORDER BY temps_écoulé_depuis_dernière_commande_en_jour DESC;

#----------------------------------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------------------------------------


#------------------------------------SATISFACTION DES CLIENTS---------------------------------------------------------------------------------------------------------

#moyenne des notes sur l'ensemble des produits
CREATE VIEW Satisfaction_par_Produit AS
SELECT 
    AVG(commander.satisfaction_client) AS moyenne_note_satisfaction
FROM
    commander;

#      ---------------

#moyenne des notes de satisfaction par catégorie
CREATE VIEW Satisfaction_par_catégorie AS
SELECT 
    catégorie.nomCatégorie AS catégoire_produit,
    AVG(commander.satisfaction_client) AS moyenne_satisfaction_par_catégorie
FROM
    catégorie
        INNER JOIN
    consommable ON catégorie.idCatégorie = consommable.idConsommable
        INNER JOIN
    produit ON consommable.idConsommable = produit.idConsommable
        INNER JOIN
    commander ON produit.idProduit = commander.idProduit
GROUP BY catégorie.idCatégorie;

#      ---------------

#afficher les délais de livraison pour les commandes qui ont eu une note <=6 ( 6 étant en dessous de la moyenne)
CREATE VIEW Clients_non_satisfait_comparé_délai_livraison AS
SELECT 
    satisfaction_client AS note_du_client, delai_livraison
FROM
    commander
WHERE
    satisfaction_client <= 6;

#      ---------------

#afficher les clients qui ont mis une note en dessous de 5 dans le but de leur demander comment s'amélorier
CREATE VIEW Clients_non_satisfaits AS
SELECT 
    client.nomClient,
    client.telephoneClient,
    commander.satisfaction_client
FROM
    client
        NATURAL JOIN
    commander
WHERE
    commander.satisfaction_client <= 5;

#------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------


#----------------------------------------SEGMENTATION DU MARCHE----------------------------------------------------------------


#segmentation des ages
CREATE VIEW Segmentation_du_marché_par_age AS
SELECT 
    'Client entre 18 et 30 ans' AS tranche_age_client,
    COUNT(commander.idClient) AS nb_commande
FROM
    client
        INNER JOIN
    commander ON client.idClient = commander.idClient
WHERE
    age BETWEEN 18 AND 30 
UNION SELECT 
    'Client entre 30 et 45 ans',
    COUNT(commander.idClient) AS nb_commande
FROM
    client
        INNER JOIN
    commander ON client.idClient = commander.idClient
WHERE
    age BETWEEN 30 AND 45 
UNION SELECT 
    'Client entre 45 et 60 ans',
    COUNT(commander.idClient) AS nb_commande
FROM
    client
        INNER JOIN
    commander ON client.idClient = commander.idClient
WHERE
    age BETWEEN 45 AND 60 
UNION SELECT 
    'Client au delà de 60 ans',
    COUNT(commander.idClient) AS nb_commande
FROM
    client
        INNER JOIN
    commander ON client.idClient = commander.idClient
WHERE
    age > 60;

#         ---------------------    
 
#segmentation du marché selon les nationnalités
CREATE VIEW Segmentation_du_marché_par_nationnalité AS
SELECT 
    client.nationnalité,
    COUNT(commander.idClient) AS nb_commande
FROM
    client
        INNER JOIN
    commander ON client.idClient = commander.idClient
GROUP BY client.nationnalité;

#         ---------------------    

#segmentation du marché selon le sexe des clients
CREATE VIEW Segmentation_du_marché_par_sexe AS
SELECT 
    client.sexe, COUNT(commander.idClient) AS nb_commande
FROM
    client
        INNER JOIN
    commander ON client.idClient = commander.idClient
GROUP BY client.sexe;

#         ---------------------    

#Selection du produit favori des hommes et des femmes
CREATE VIEW Produit_favoris_Homme_vs_Femme AS
SELECT 
    client.sexe,
    consommable.nomConsomable AS Produit_favori,
    COUNT(commander.idClient) AS nb_commande
FROM
    consommable
        INNER JOIN
    produit ON consommable.idConsommable = produit.idProduit
        INNER JOIN
    commander ON produit.idProduit = commander.idProduit
        INNER JOIN
    client ON commander.idClient = client.idClient
GROUP BY consommable.idConsommable
HAVING client.sexe = 'H' 
UNION SELECT 
    client.sexe,
    consommable.nomConsomable,
    COUNT(commander.idClient)
FROM
    consommable
        INNER JOIN
    produit ON consommable.idConsommable = produit.idProduit
        INNER JOIN
    commander ON produit.idProduit = commander.idProduit
        INNER JOIN
    client ON commander.idClient = client.idClient
GROUP BY consommable.idConsommable
HAVING client.sexe = 'F'
ORDER BY nb_commande DESC
LIMIT 2;

