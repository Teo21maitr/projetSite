var _cptGruyere = 0;
var  _flagContinueGame = true;
window.setTimeout(stopGame, 10000);

function  stopGame() {
    _flagContinueGame = false;
    document.getElementById("gruyère").style.display = "none";
}

function mouseMove (e) {
    let Souris = document.getElementById("souris");
    let Gruyère = document.getElementById("gruyère");

    let pointerX = e.clientX;
    let pointerY = e.clientY;

    let sourisX = pointerX - 25;
    let sourisY = pointerY -25;

    let gruyereTopLeftX = Gruyère.offsetLeft;
    let gruyereTopLeftY = Gruyère.offsetTop;



    //console.log(`Coordonée X : ${pointerX}, Coordonée Y ${pointerY}`)

    Souris.style.left = sourisX + "px";
    Souris.style.top = sourisY + "px";

    let distance = Math.sqrt(Math.pow(sourisX-gruyereTopLeftX,2) + Math.pow(sourisY-gruyereTopLeftY,2));

    if (distance < 50 && _flagContinueGame == true){
        let newX = Math.random()*750;
        let newY = Math.random()*750;
        Gruyère.style.left = newX + "px";
        Gruyère.style.top = newY + "px";
        _cptGruyere = _cptGruyere + 1
        document.getElementById('score').innerHTML = _cptGruyere; 
        
    }



}
